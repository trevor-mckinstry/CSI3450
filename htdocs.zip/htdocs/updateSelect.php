<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<form action="http://localhost/updateHero.php" method="post">
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT idHero, NAME FROM hero ORDER BY NAME ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo "<table><tr><th>Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo '<td>';
					echo $row['NAME'];
					echo '</td>';
					echo '<td><button type="submit" name = "HeroID" id="HeroID"';
					echo 'value='. $row['idHero'] .'>';
					echo 'UPDATE';
					echo '</button></td>';
					echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>
</form>
<a href=http://localhost/heros.php>Cancel</a>
</body>
</html>