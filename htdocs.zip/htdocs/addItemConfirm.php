<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['Item_id'])){
$ITEM_ID = $_POST['Item_id'];
$ITEM_NAME = $_POST['Item_name'];
$ITEM_COST = $_POST['item_cost'];
if(isset($_POST['Item_stat1'])){
$ITEM_STAT1 = $_POST['Item_stat1'];
$ITEM_VAL1 = $_POST['Item_val1'];
}else{
	$ITEM_STAT1 = NULL;
	$ITEM_VAL1 = NULL;
}

if(isset($_POST['Item_stat2'])){
$ITEM_STAT2 = $_POST['Item_stat2'];
$ITEM_VAL2 = $_POST['Item_val2'];
}else{
	$ITEM_STAT2 = NULL;
	$ITEM_VAL2 = NULL;
}
if(isset($_POST['Item_stat3'])){
$ITEM_STAT3 = $_POST['Item_stat3'];
$ITEM_VAL3 = $_POST['Item_val3'];
}else{
	$ITEM_STAT3 = NULL;
	$ITEM_VAL3 = NULL;
}
if(isset($_POST['Item_ably'])){
$ITEM_ABILITYNAME = $_POST['Item_ably'];
$ITEM_ABILITYEFFECT1 = $_POST['Item_ablyeft1'];
$ITEM_ABILITYEFFECT1_VAL = $_POST['Item_ablyval1'];
}else{
	$ITEM_ABILITYNAME = NULL;
	$ITEM_ABILITYEFFECT1 = NULL;
	$ITEM_ABILITYEFFECT1_VAL = NULL;
}
if(isset($_POST['Item_ablyeft2'])){
$ITEM_ABILITYEFFECT2 = $_POST['Item_ablyeft2'];
$ITEM_ABILITYEFFECT2_VAL = $_POST['Item_ablyval2'];
}else{
	$ITEM_ABILITYEFFECT2 = NULL;
	$ITEM_ABILITYEFFECT2_VAL = NULL;
}
if(isset($_POST['Item_ablycd'])){
$ITEM_ABILITY_CD = $_POST['Item_ablycd'];
}else{
	$ITEM_ABILITY_CD = NULL;
}
if(isset($_POST['Item_loc'])){
$ITEM_LOCATION = $_POST['Item_loc'];
}else{
	$ITEM_LOCATION = NULL;
}
if(isset($_POST['Item_range'])){
$ITEM_ABILITY_RANGE = $_POST['Item_range'];
}else{
	$ITEM_ABILITY_RANGE = NULL;
}
if(isset($_POST['Item_ablycost'])){
$ITEM_ABILITY_COST = $_POST['Item_ablycost'];
}else{
	$ITEM_ABILITY_COST = NULL;
}
$sql = 'INSERT INTO item (iditem, NAME, COST, STAT1, STAT1_VAL, STAT2, STAT2_VAL, STAT3, STAT3_VAL, ABILITYNAME, ABILITYEFFECT1, ABILITYEFFECT1_VAL, ABILITYEFFECT2, ABILITYEFFECT2_VAL, ABILITY_CD, LOCATION, ABILITY_RANGE, ABILITY_COST) VALUES (' . $ITEM_ID .', '. $ITEM_NAME .', '. $ITEM_COST .','. $ITEM_STAT1 .', '. $ITEM_VAL1 .', '. $ITEM_STAT2 .', '. $ITEM_VAL2 .', '. $ITEM_STAT3 .', '. $ITEM_VAL3 .', '. $ITEM_ABILITYNAME .', '. $ITEM_ABILITYEFFECT1 .', '. $ITEM_ABILITYEFFECT1_VAL .', '. $ITEM_ABILITYEFFECT2 .', '. $ITEM_ABILITYEFFECT2_VAL .', '. $ITEM_ABILITY_CD .', '. $ITEM_LOCATION .', '. $ITEM_ABILITY_RANGE .', '. $ITEM_ABILITY_COST .')';
	if ($conn->query($sql) === TRUE) {
		echo "Record added successfully<br>";
	} else {
		echo "Error adding record: " . $conn->error;
	}
}

$conn->close();
?>
<a href=http://localhost/items.php>Return</a>
</body>
</html>