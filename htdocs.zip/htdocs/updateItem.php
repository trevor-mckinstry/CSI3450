<html>  

    <head>
    <link rel="stylesheet" href="style.css">
    
    <title>
   
    </title>
        
 </head>
    

<form action="http://localhost/updateItemConfirm.php" method="post">
  <div class="container">
    <p>Please fill in this form to update a item.</p>
<?php
	$HeroID = $_POST['ItemID'];
	echo '<input type="hidden" id="Item_id" name="Item_id" value='. $ItemID .'>';
	?>
	<div class="container">
    <hr>


    <label for="Item_name"><b>Name</b></label>
    <input type="text" placeholder="" name="Item_name" id="Item_name" required>
    
      <label for="Item_cost"><b>Cost</b></label>
    <input type="text" placeholder="" name="Item_cost" id="Item_cost" required>
       
      <label for="Item_stat1"><b>Stat 1</b></label>
    <input type="text" placeholder="" name="Item_stat1" id="Item_stat1" >
      
       <label for="Item_val1"><b>Stat 1 Value</b></label>
    <input type="text" placeholder="" name="Item_val1" id="Item_val1" >

    <label for="Item_stat2"><b>Stat 2</b></label>
    <input type="text" placeholder="" name="Item_stat2" id="Item_stat2" >

    <label for="Item_val2"><b>Stat 2 Value</b></label>
    <input type="text" placeholder="" name="Item_val2" id="Item_val2" >
	
	<label for="Item_stat3"><b>Stat 3</b></label>
    <input type="text" placeholder="" name="Item_stat3" id="Item_stat3" >

    <label for="Item_val3"><b>Stat 3 Value</b></label>
    <input type="text" placeholder="" name="Item_val3" id="Item_val3" >
    
      <label for="Item_ably"><b>Ability Name</b></label>
    <input type="text" placeholder="" name="Item_ably" id="Item_ably">
       
      <label for="Item_ablyeft1"><b>Ability Effect 1</b></label>
    <input type="text" placeholder="" name="Item_ablyeft1" id="Item_ablyeft1" >
      
       <label for="Item_ablyval1"><b>Ability Effect 1 Value</b></label>
    <input type="text" placeholder="" name="Item_ablyval1" id="Item_ablyval1" >

    <label for="Item_ablyeft2"><b>Ability Effect 2</b></label>
    <input type="text" placeholder="" name="Item_ablyeft2" id="Item_ablyeft2" >

    <label for="Item_ablyval2"><b>Ability Effect 2 Value</b></label>
    <input type="text" placeholder="" name="Item_ablyval2" id="Item_ablyval2" >
	
	<label for="Item_ablycd"><b>Ability Cooldown</b></label>
    <input type="text" placeholder="" name="Item_ablycd" id="Item_ablycd" >
      
       <label for="Item_loc"><b>Ability Location</b></label>
    <input type="text" placeholder="" name="Item_loc" id="Item_loc" >

    <label for="Item_range"><b>Ability Range</b></label>
    <input type="text" placeholder="" name="Item_range" id="Item_range" >
	 <label for="Item_ablycost"><b>Ability Cost</b></label>
    <input type="text" placeholder="" name="Item_ablycost" id="Item_ablycost" >

    
    <hr>

    <button type="submit" class="registerbtn">Update</button>
  </div>

  <div class="container signin">
    <p><a href="http://localhost/item.php">Cancel</a></p>
  </div>
</form> 