<html>
    <head>
	<link rel="stylesheet" href="style.css">
        <title>One Hero</title>
    </head>
    <body>
		<?php
$servername = "localhost";
$username = "root";
$password = "1Drop2Drop";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['HeroID'])){
				$HeroID = $_POST['HeroID'];
				$sql = "SELECT * FROM hero WHERE idHero = " . $HeroID . " ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo "<table><tr><th>". $row['NAME'] ."</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo '<td>Name: ';
					echo $row['NAME'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Primary Attribute: ';
					echo $row['ATTRI'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Strength: ';
					echo $row['STRENGTH'];
					echo ' + ';
					echo $row['STR_GAIN'];
					echo ' Per Level</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Agility: ';
					echo $row['AGILITY'];
					echo ' + ';
					echo $row['AGI_GAIN'];
					echo ' Per Level</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Intelligence: ';
					echo $row['INTELLIGENCE'];
					echo ' + ';
					echo $row['INT_GAIN'];
					echo ' Per Level</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Health: ';
					echo $row['LIFE'];
					echo ' + ';
					echo $row['LIFE_GAIN'];
					echo ' Per Level</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Mana: ';
					echo $row['MANA'];
					echo ' + ';
					echo $row['MANA_GAIN'];
					echo ' Per Level</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Armor: ';
					echo $row['ARMOR'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Magic Resistance: ';
					echo $row['RESIST'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Speed: ';
					echo $row['SPEED'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Turn Speed: ';
					echo $row['TURN'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Damage: ';
					echo $row['DAMAGE'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Attack Range: ';
					echo $row['ATTRANGE'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Basic Attack Time: ';
					echo $row['BAT'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Vision: ';
					echo $row['VISIONDAY'];
					echo '/';
					echo $row['VISIONNIGHT'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Aghanims Scepter effect';
					echo $row['AGHS'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Aghanims Shard effect :';
					echo $row['SHARD'];
					echo '</td>';
					echo "</tr>";
    }
    echo "</table>";
}
	$sql = "SELECT * FROM ability WHERE Hero_idHero = " . $HeroID . " ";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo "<table><tr><th>Abilities</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo '<td>';
					echo $row['NAME'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>';
					echo $row['TYPE'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>';
					echo $row['PIERCE'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>';
					echo $row['RANGE'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>';
					echo $row['DESCRIPTION'];
					echo '</td>';
					echo "</tr>";
					if(isset($row['EFFECT'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT'];
					echo ': ';
					echo $row['VALUE'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 2'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 2'];
					echo ': ';
					echo $row['VALUE 2'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 3'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 3'];
					echo ': ';
					echo $row['VALUE 3'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 4'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 4'];
					echo ': ';
					echo $row['VALUE 4'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 5'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 5'];
					echo ': ';
					echo $row['VALUE 5'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 6'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 6'];
					echo ': ';
					echo $row['VALUE 6'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['EFFECT 7'])){
					echo "<tr>";
					echo '<td>';
					echo $row['EFFECT 7'];
					echo ': ';
					echo $row['VALUE 7'];
					echo '</td>';
					echo "</tr>";
					}
					echo "<tr><td><br></td></tr>";

	}
	echo "</table>";
}
}

$conn->close();
?>
    </body>
</html>
