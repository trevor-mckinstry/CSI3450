<html>
    <head>
	<link rel="stylesheet" href="style.css">
        <title>One Item</title>
    </head>
    <body>
		<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['ItemID'])){
				$ItemID = $_POST['ItemID'];
				$sql = "SELECT * FROM item WHERE idItem = " . $ItemID . " ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo "<table><tr><th>". $row['NAME'] ."</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo "<tr>";
					echo '<td>Name: ';
					echo $row['NAME'];
					echo '</td>';
					echo "</tr>";
					echo "<tr>";
					echo '<td>Price: ';
					echo $row['COST'];
					echo '</td>';
					echo "</tr>";
					if(isset($row['STAT1'])){
					echo "<tr>";
					echo '<td>';
					echo $row['STAT1'];
					echo ' : ';
					echo $row['STAT1_VAL'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['STAT2'])){
					echo "<tr>";
					echo '<td>';
					echo $row['STAT2'];
					echo ' : ';
					echo $row['STAT2_VAL'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['STAT3'])){
					echo "<tr>";
					echo '<td>';
					echo $row['STAT3'];
					echo ' : ';
					echo $row['STAT3_VAL'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['ABILITYNAME'])){
					echo "<tr>";
					echo '<td>';
					echo $row['ABILITYNAME'];
					echo "</tr>";
					echo "<tr>";
					echo '<td>';
					echo $row['ABILITYEFFECT1'];
					echo ' : ';
					echo $row['ABILITYEFFECT1_VAL'];
					echo '</td>';
					echo "</tr>";
					if(isset($row['ABILITYEFFECT2'])){
					echo "<tr>";
					echo '<td>';
					echo $row['ABILITYEFFECT2'];
					echo ' : ';
					echo $row['ABILITYEFFECT2_VAL'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['ABILITY_CD'])){
					echo "<tr>";
					echo '<td>Cooldown: ';
					echo $row['ABILITY_CD'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['LOCATION'])){
					echo "<tr>";
					echo '<td>Location: ';
					echo $row['LOCATION'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['ABILITY_RANGE'])){
					echo "<tr>";
					echo '<td>Range: ';
					echo $row['ABILITY_RANGE'];
					echo '</td>';
					echo "</tr>";
					}
					if(isset($row['ABILITY_COST'])){
					echo "<tr>";
					echo '<td>Mana Cost: ';
					echo $row['ABILITY_COST'];
					echo '</td>';
					echo "</tr>";
					}
					}
    }
    echo "</table>";
}
}

$conn->close();
?>
    </body>
</html>
