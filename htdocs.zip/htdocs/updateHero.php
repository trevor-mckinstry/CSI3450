<html>  

    <head>
    <link rel="stylesheet" href="style.css">
    
    <title>
   
    </title>
        
 </head>
    

<form action="http://localhost/updateHeroConfirm.php" method="post">
  <div class="container">
    <p>Please fill in this form to update a hero.</p>
<?php
	$HeroID = $_POST['HeroID'];
	echo '<input type="hidden" id="hero_id" name="hero_id" value='. $HeroID .'>';
	?>
	<label for="hero_pri"><b>Primary Attribute</b></label>
    <input type="text" placeholder="Enter Primary Attribute" name="hero_pri" id="hero_pri" required>

    <label for="hero_name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="hero_name" id="hero_name" required>
    
      <label for="hero_desc"><b>Description</b></label>
    <input type="text" placeholder="Enter Description" name="hero_desc" id="hero_desc" required>
       
      <label for="hero_life"><b>Health</b></label>
    <input type="text" placeholder="Enter Health" name="hero_life" id="hero_life" required>
      
       <label for="hero_lifergn"><b>Health per Level</b></label>
    <input type="text" placeholder="Enter Health per Level" name="hero_lifergn" id="hero_lifergn" required>

    <label for="hero_mana"><b>Mana</b></label>
    <input type="text" placeholder="Enter Mana" name="hero_mana" id="hero_mana" required>

    <label for="hero_manargn"><b>Mana per Level</b></label>
    <input type="text" placeholder="Enter Mana per Level" name="hero_manargn" id="hero_manargn" required>
	
	<label for="hero_str"><b>Strength</b></label>
    <input type="text" placeholder="Enter Strength" name="hero_str" id="hero_str" required>

    <label for="hero_strgain"><b>Strength per Level</b></label>
    <input type="text" placeholder="Enter Strength per Level" name="hero_strgain" id="hero_strgain" required>
    
      <label for="hero_int"><b>Intelligence</b></label>
    <input type="text" placeholder="Enter Intelligence" name="hero_int" id="hero_int" required>
       
      <label for="hero_intgain"><b>Intelligence per Level</b></label>
    <input type="text" placeholder="Enter Intelligence per Level" name="hero_intgain" id="hero_intgain" required>
      
       <label for="hero_agi"><b>Agility</b></label>
    <input type="text" placeholder="Enter Agility" name="hero_agi" id="hero_agi" required>

    <label for="hero_agigain"><b>Agility per Level</b></label>
    <input type="text" placeholder="Enter Agility per Level" name="hero_agigain" id="hero_agigain" required>

    <label for="hero_damage"><b>Damage</b></label>
    <input type="text" placeholder="Repeat Damage" name="hero_damage" id="hero_damage" required>
	
	<label for="hero_armor"><b>Armor</b></label>
    <input type="text" placeholder="Enter Armor" name="hero_armor" id="hero_armor" required>
      
       <label for="hero_speed"><b>Speed</b></label>
    <input type="text" placeholder="Enter Speed" name="hero_speed" id="hero_speed" required>

    <label for="hero_turn"><b>Turn Speed</b></label>
    <input type="text" placeholder="Enter Turn Speed" name="hero_turn" id="hero_turn" required>

    <label for="hero_vision_day"><b>Day Vision</b></label>
    <input type="text" placeholder="Enter Day Vision" name="hero_vision_day" id="hero_vision_day" required>
	<label for="hero_vision_night"><b>Night Vision</b></label>
    <input type="text" placeholder="Enter Night Vision" name="hero_vision_night" id="hero_vision_night" required>
	<label for="hero_resist"><b>Magic Resistance</b></label>
    <input type="text" placeholder="Enter Magic Resistance" name="hero_resist" id="hero_resist" required>
    <hr>

    <button type="submit" class="registerbtn">Update</button>
  </div>

  <div class="container signin">
    <p><a href="http://localhost/heros.php">Cancel</a></p>
  </div>
</form> 