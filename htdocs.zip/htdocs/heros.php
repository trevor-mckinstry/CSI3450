<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT idHero, NAME FROM hero ORDER BY NAME ASC";
if(isset($_POST['strSelect'])){
	$sql = "SELECT idHero, NAME FROM hero WHERE ATTRI LIKE 'Strength' ORDER BY NAME ASC";
	echo '<h1>Strength</h1>';
}
if(isset($_POST['intSelect'])){
	$sql = "SELECT idHero, NAME FROM hero WHERE ATTRI LIKE 'Intelligence' ORDER BY NAME ASC";
	echo '<h1>Intelligence</h1>';
}
if(isset($_POST['agiSelect'])){
	$sql = "SELECT idHero, NAME FROM hero WHERE ATTRI LIKE 'Agility' ORDER BY NAME ASC";
	echo '<h1>Agility</h1>';
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo '<table><tr><th><form action="http://localhost/items.php" method="post"><button type="submit" name = "toItem" id="toItem" value = 1>Items</button></form>';
	echo '<form action="http://localhost/heros.php" method="post"><button type="submit" name = "strSelect" id="strSelect" value = 1>STR</button><button type="submit" name = "intSelect" id="intSelect" value = 1>INT</button><button type="submit" name = "agiSelect" id="agiSelect" value = 1>AGI</button>';
	echo '</form></th></tr>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo '<form action="http://localhost/oneHero.php" method="post">';
					echo "<tr>";
					echo '<td><button type="submit" name = "HeroID" id="HeroID"';
					echo 'value='. $row['idHero'] .'>';
					echo $row['NAME'];
					echo '</button></td>';
					echo "</tr>";
					echo '</form>';
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

<a href=http://localhost/deleteSelect.php>Delete</a>
<a href=http://localhost/addHero.php>Add</a>
<a href=http://localhost/updateSelect.php>Update</a>
</body>
</html>