<html>
<head>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['HeroID'])){

	$HeroID = $_POST['HeroID'];
	$sql = "DELETE FROM hero WHERE idHero = " . $HeroID . " ";
	if ($conn->query($sql) === TRUE) {
		echo "Record deleted successfully<br>";
	} else {
		echo "Error deleting record: " . $conn->error;
	}
}

$conn->close();
?>
<a href=http://localhost/heros.php>Return</a>
</body>
</html>