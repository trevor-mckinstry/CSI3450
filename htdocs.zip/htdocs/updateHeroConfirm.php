<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['hero_id'])){
$HERO_ID = $_POST['hero_id'];
$HERO_NAME = $_POST['hero_name'];
$HERO_PRIMARY = $_POST['hero_primary'];
$HERO_LIFE = $_POST['hero_life'];
$HERO_LIFERGN = $_POST['hero_lifergn'];
$HERO_MANA = $_POST['hero_mana'];
$HERO_MANARGN = $_POST['hero_manargn'];
$HERO_STR = $_POST['hero_str'];
$HERO_STRGAIN = $_POST['hero_strgain'];
$HERO_INT = $_POST['hero_int'];
$HERO_INTGAIN = $_POST['hero_intgain'];
$HERO_AGI = $_POST['hero_agi'];
$HERO_AGIGAIN = $_POST['hero_agigain'];
$HERO_DAMAGE = $_POST['hero_damage'];
$HERO_ARMOR = $_POST['hero_armor'];
$HERO_SPEED = $_POST['hero_speed'];
$HERO_TURN = $_POST['hero_turn'];
$HERO_VISIONDAY = $_POST['hero_visionday'];
$HERO_VISIONNIGHT = $_POST['hero_visionnight'];
$HERO_RESIST = $_POST['hero_resist'];
$HERO_AGHS = $_POST['hero_aghs'];
$HERO_SHARD = $_POST['hero_shard'];


$sql = 'UPDATE hero SET NAME = '. $HERO_NAME .' , LIFE = '. $HERO_LIFE .' , LIFE_GAIN = '. $HERO_LIFERGN .'
, MANA = '. $HERO_MANA .' , MANA_GAIN = '. $HERO_MANARGN .' , STRENGTH = '. $HERO_STR .' , STR_GAIN = '. $HERO_STRGAIN .'
, INTELLIGENCE = '. $HERO_INT .' , INT_GAIN = '. $HERO_INTGAIN .' , AGILITY = '. $HERO_AGI .' , AGI_GAIN = '. $HERO_AGIGAIN .'
, DAMAGE = '. $HERO_DAMAGE .' , ARMOR = '. $HERO_ARMOR .' , SPEED = '. $HERO_SPEED .' , TURN = '. $HERO_TURN .'
, VISIONDAY = '. $HERO_VISIONDAY .' , VISIONNIGHT = '. $HERO_VISIONNIGHT .', HERO_RESIST = '. $HERO_RESIST .'  
, AGHS = '. $HERO_AGHS .' , SHARD = '. $HERO_SHARD .' , ATTRI = '. $HERO_PRIMARY .' WHERE idHero = '. $HERO_ID .'';
	if ($conn->query($sql) === TRUE) {
		echo "Record updated successfully<br>";
	} else {
		echo "Error updating record: " . $conn->error;
	}
}
$conn->close();
?>
<a href=http://localhost/heros.php>Return</a>
</body>
</html>