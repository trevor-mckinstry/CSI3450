<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['hero_id'])){
$HERO_ID = $_POST['hero_id'];
$HERO_NAME = $_POST['hero_name'];
$HERO_PRIMARY = $_POST['hero_primary'];
$HERO_LIFE = $_POST['hero_life'];
$HERO_LIFERGN = $_POST['hero_lifergn'];
$HERO_MANA = $_POST['hero_mana'];
$HERO_MANARGN = $_POST['hero_manargn'];
$HERO_STR = $_POST['hero_str'];
$HERO_STRGAIN = $_POST['hero_strgain'];
$HERO_INT = $_POST['hero_int'];
$HERO_INTGAIN = $_POST['hero_intgain'];
$HERO_AGI = $_POST['hero_agi'];
$HERO_AGIGAIN = $_POST['hero_agigain'];
$HERO_DAMAGE = $_POST['hero_damage'];
$HERO_ARMOR = $_POST['hero_armor'];
$HERO_SPEED = $_POST['hero_speed'];
$HERO_TURN = $_POST['hero_turn'];
$HERO_VISIONDAY = $_POST['hero_visionday'];
$HERO_VISIONNIGHT = $_POST["hero_visionnight"];
$HERO_RESIST = $_POST['hero_resist'];
$HERO_AGHS = $_POST['hero_aghs'];
$HERO_SHARD = $_POST['hero_shard'];
$HERO_BAT = $_POST['hero_bat'];
$HERO_RANGE = $_POST['hero_range'];

$sql = 'INSERT INTO hero (idHero, NAME, ATTRI, STRENGTH, STR_GAIN, AGILITY, AGI_GAIN, INTELLIGENCE, INT_GAIN, LIFE, LIFE_GAIN, MANA, MANA_GAIN, ARMOR, SPEED, DAMAGE, ATTRANGE, BAT, TURN, VISIONDAY, VISIONNIGHT, RESIST, AGHS, SHARD) VALUES (' . $HERO_ID .', '. $HERO_NAME .', '. $HERO_PRIMARY .',  '. $HERO_STR .', '. $HERO_STRGAIN .', '. $HERO_AGI .', '. $HERO_AGIGAIN .', '. $HERO_INT .', '. $HERO_INTGAIN .',  '. $HERO_LIFE .', '. $HERO_LIFERGN .', '. $HERO_MANA .', '. $HERO_MANARGN .', '. $HERO_ARMOR .', '. $HERO_SPEED .', '. $HERO_DAMAGE .', '. $HERO_RANGE .', '. $HERO_BAT .',   '. $HERO_TURN .', '. $HERO_VISIONDAY .', '. $HERO_VISIONNIGHT .', '. $HERO_RESIST .',  '. $HERO_AGHS .', '. $HERO_SHARD .' )';
	if ($conn->query($sql) === TRUE) {
		echo "Record added successfully<br>";
	} else {
		echo "Error adding record: " . $conn->error;
	}
}

$conn->close();
?>
<a href=http://localhost/heros.php>Return</a>
</body>
</html>