<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "Password";
$dbname = "cs3450";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT idItem, NAME FROM item ORDER BY NAME ASC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
	//echo "not 0 results";
    echo '<table><tr><th>Name</th></tr>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
					echo '<form action="http://localhost/oneItem.php" method="post">';
					echo "<tr>";
					echo '<td><button type="submit" name = "ItemID" id="ItemID"';
					echo 'value='. $row['idItem'] .'>';
					echo $row['NAME'];
					echo '</button></td>';
					echo "</tr>";
					echo '</form>';
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>

<a href=http://localhost/deleteSelectItem.php>Delete</a>
<a href=http://localhost/addItem.php>Add</a>
<a href=http://localhost/updateSelectItem.php>Update</a>
</body>
</html>