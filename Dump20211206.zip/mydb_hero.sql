-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `hero`
--

DROP TABLE IF EXISTS `hero`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hero` (
  `idHero` int NOT NULL,
  `NAME` varchar(45) DEFAULT NULL,
  `PRIMARY` varchar(45) DEFAULT NULL,
  `STRENGTH` int DEFAULT NULL,
  `STR_GAIN` decimal(10,1) DEFAULT NULL,
  `AGILITY` int DEFAULT NULL,
  `AGI_GAIN` decimal(10,1) DEFAULT NULL,
  `INTELLIGENCE` int DEFAULT NULL,
  `INT_GAIN` decimal(10,1) DEFAULT NULL,
  `LIFE` int DEFAULT NULL,
  `LIFE_GAIN` decimal(10,1) DEFAULT NULL,
  `MANA` int DEFAULT NULL,
  `MANA_GAIN` decimal(10,1) DEFAULT NULL,
  `ARMOR` decimal(10,1) DEFAULT NULL,
  `SPEED` int DEFAULT NULL,
  `DAMAGE` varchar(10) DEFAULT NULL,
  `ATTRANGE` int DEFAULT NULL,
  `BAT` decimal(10,1) DEFAULT NULL,
  `TURN` decimal(10,1) DEFAULT NULL,
  `VISIONDAY` int DEFAULT NULL,
  `VISIONNIGHT` int DEFAULT NULL,
  `RESIST` int DEFAULT NULL,
  `AGHS` varchar(400) DEFAULT NULL,
  `SHARD` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`idHero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hero`
--

LOCK TABLES `hero` WRITE;
/*!40000 ALTER TABLE `hero` DISABLE KEYS */;
INSERT INTO `hero` VALUES (1,'Abaddon','Strength',22,2.8,23,1.5,18,2.0,640,3.2,291,0.9,2.8,325,'50-60',150,1.7,0.6,1800,800,25,'Increases duration of Borrowed Time. While Borrowed Time is active, anytime an ally takes more than 525 damage while within 1600 range of Abaddon, an individual Mist Coil will automatically fire towards that ally.','Causes Mist Coil and Aphotic Shield to apply a Curse of Avernus stack on enemies. Increase base slow by 10%. Lowers Cooldown for Mist Coil and Aphotic Shield by 1 second.'),(2,'Alchemist','Strength',25,2.9,22,1.5,25,1.8,700,2.8,375,2.5,2.7,305,'52-58',150,1.7,0.6,1800,800,25,'Alchemist melts down Aghanim\'s Scepter to grant an allied hero all Aghanim\'s Scepter upgrades. When you have a Scepter of your own, you will gain bonus damage and spell amplification for each gifted Scepter.','Adds \'Berserk Potion\' Ability'),(3,'Ancient Apparition','Intelligence',20,1.9,20,2.2,23,3.4,600,2.3,351,1.2,2.3,285,'44-54',675,1.7,0.6,1800,800,25,'Removes cooldown of Chilling Touch and reduces manacost by half.','Causes Ice Vortex to deal 40 DPS and reduces attack speed by 20.'),(4,'Anti-Mage','Agility',23,1.6,24,2.8,12,1.8,660,2.6,219,0.6,4.0,310,'53-57',150,1.4,0.6,1800,800,25,'Adds \'Blink Fragment\' Ability','Counterspell passively grants a 900 radius aura that reduces enemy spell damage by 10%. Reduces spell damage by an additional 20% to enemies within 300 range'),(5,'Arc Warden','Agility',22,2.6,20,2.5,24,2.6,640,2.5,363,1.2,2.3,285,'47-57',625,1.7,0.7,1800,800,25,'Causes Spark Wraiths to spawn a new Spark Wraith after impacting an enemy, which then starts its 3 second activation period.','Magnetic Field pushes enemies out of the area when cast, and provides allies in it with +40% Magic Resistance. Slows enemies inside by 30%.'),(6,'Axe','Strength',25,3.4,20,2.2,18,1.6,700,5.3,291,0.9,2.3,310,'52-56',150,1.7,0.6,1800,800,25,'Berserker\'s Call applies Battle Hunger to affected units. Battle Hunger also reduces enemy armor by 7 and grants Axe 7 armor per affected target.  Reduces Berserker\'s Call Cooldown by 3. ','Counter Helix now applies a stacking -20% Attack Damage debuff for 6s to enemies hit by it. Increases Counter Helix Chance by 10%.'),(7,'Bane','Intelligence',22,2.5,22,2.5,22,2.5,640,2.5,339,1.1,4.7,305,'55-61',400,1.7,0.6,1800,1200,25,'Reduces Fiend\'s Grip cooldown by 45 seconds. Fiend\'s Grip now creates two uncontrollable illusions that are also channeling Fiend\'s Grip on the target. Illusions takes 700% incoming damage and immediately dies if they are interrupted. Damage does not stack.','Causes Brain Sap to become a 550 AoE spell. Secondary targets only heal for 25%.'),(8,'Batrider','Intelligence',28,2.9,15,1.8,22,2.9,760,4.6,339,1.1,3.5,300,'39-43',400,1.7,0.9,1600,800,25,'Flaming Lasso grabs both its target, as well as the target\'s nearest allied hero within range. The secondary target is tethered to the first.','Causes Flamebreak to have two charges and apply a Sticky Napalm charge on impact.'),(9,'Beastmaster','Strength',23,2.9,18,1.6,16,1.9,660,2.5,267,0.8,3.0,305,'56-60',150,1.7,0.6,1800,800,25,'Causes Wild Axes to have no cooldown and can be used again once they come back.','Reduces Hawk cooldown by 7 seconds. Hawks gains Dive Bomb. Channels for 1 second, revealing itself, and then flies towards the target enemy, dealing 250 damage and stunning them for 2 seconds, killing the hawk. Cast Range: 1200.'),(10,'Bloodseeker','Agility',24,2.7,22,3.1,17,2.0,680,2.7,279,0.9,5.7,300,'57-63',150,1.7,0.6,1800,800,25,'Grants Bloodseeker two charges of Rupture and reduces Rupture\'s Cooldown to 40s','Bloodrage attacks now deal 2% of the target’s max health as pure damage and heals Bloodseeker for that amount. Only works for Bloodseeker.'),(11,'Bounty Hunter','Agility',20,2.5,21,2.6,22,1.9,600,3.3,339,1.6,7.5,320,'51-59',150,1.7,0.6,1800,1000,25,'Upgrades Shuriken Toss. Applies Jinada to it and increases cast range.','Shadow Walk grants you 35% damage reduction while invisible. Attacking out of invisibility stuns the target for 1 second. Lowers cooldown by 5 seconds.'),(12,'Brewmaster','Strength',23,3.7,19,2.0,15,1.6,660,2.8,255,0.8,2.2,310,'52-59',150,1.7,0.6,1800,800,25,'Primal Split has 2 charges and can be canceled at any time. Charge replenish time is equal to the normal cooldown.','Primal Split now creates a Void brewling. Has Astral Pulse ability, affecting enemies in 500 AoE. Applies a 20/30/40% slow and Disarm for 2 seconds. Void Brewling inherits Brewmaster\'s Attack Modifiers'),(13,'Bristleback','Strength',22,2.9,17,1.8,14,2.8,640,2.5,243,0.9,3.8,290,'52-58',150,1.8,0.9,1800,800,25,'Viscous Nasal Goo becomes a no target area of effect ability, applying to all enemies within range. Increases Stack Limit to 7.','Adds \'Hairball\' Ability'),(14,'Broodmother','Agility',18,3.2,19,3.4,18,2.0,560,2.1,291,0.9,3.2,280,'48-54',150,1.7,0.6,1800,800,25,'Adds \'Spinner\'s Snare\' Abillity','Causes Silken Bola to be a 550 AoE spell and increases the miss chance to 80%'),(15,'Centaur Warrunner','Strength',27,4.6,15,1.0,15,1.6,740,3.0,255,0.8,2.5,300,'63-65',150,1.7,0.6,1800,800,25,'Heroes affected by Stampede take reduced damage, and are able to run through obstructions, including trees and up cliffs. Increases duration by 1 second.','Causes Double Edge to increase Centaur\'s strength by 15% per hero hit for 15 seconds. Duration refreshes per stack. Max 5 Stacks. Slows enemies by 25% for 2 seconds.'),(16,'Chaos Knight','Strength',22,3.2,18,1.4,18,1.2,640,2.5,291,0.9,5.0,325,'51-81',150,1.7,0.6,1800,800,25,'Phantasm creates an illusion of allied heroes. Creates an additional illusion for Chaos Knight as well.','Chaos Bolt creates a Phantasm illusion attacking the target for 6 seconds. Increases cast range by 300.'),(17,'Chen','Intelligence',25,2.0,15,2.1,19,3.2,700,2.8,303,1.5,1.5,300,'46-56',650,1.7,0.6,1800,800,25,'Hand of God Applies a Strong Dispel to all allies.','Allows Holy Persuasion to target Ancient Creeps. Can control up to 1/2/3 Ancient Creeps based on Hand of God\'s level.'),(18,'Clinkz','Agility',16,2.0,22,2.5,18,2.2,520,1.9,291,0.9,3.7,290,'37-43',600,1.7,0.6,1800,800,25,'Adds \'Burning Army\' Ability','Causes Skeleton Walk to create two Burning Army Skeletons.'),(19,'Clockwerk','Strength',26,3.5,13,2.3,18,1.5,720,2.9,291,0.9,3.2,310,'50-52',150,1.7,0.6,1800,800,25,'Adds \'Overclocking\' Ability','Adds \'Jetpack\' Ability'),(20,'Crystal Maiden','Intelligence',18,2.2,16,1.6,16,3.3,560,2.1,267,1.8,1.7,280,'44-50',600,1.7,0.6,1800,800,25,'Applies Frostbite to any unit that has been standing in the Freezing Field for over a set amount of time.','Allows you to move, cast and attack during Freezing Field. Can still be interrupted by enemies. You move 75% slower during this. Increases total number of explosions by 20.0%.');
/*!40000 ALTER TABLE `hero` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-06 21:43:34
