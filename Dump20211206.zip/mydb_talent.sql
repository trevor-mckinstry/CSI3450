-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `talent`
--

DROP TABLE IF EXISTS `talent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `talent` (
  `idTalent` int NOT NULL,
  `LEVEL` int DEFAULT NULL,
  `DESCRIPTION` varchar(45) DEFAULT NULL,
  `Hero_idHero` int NOT NULL,
  PRIMARY KEY (`idTalent`),
  KEY `fk_Talent_Hero_idx` (`Hero_idHero`),
  CONSTRAINT `fk_Talent_Hero` FOREIGN KEY (`Hero_idHero`) REFERENCES `hero` (`idHero`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `talent`
--

LOCK TABLES `talent` WRITE;
/*!40000 ALTER TABLE `talent` DISABLE KEYS */;
INSERT INTO `talent` VALUES (1,10,'8 Strength',1),(2,10,'15 Movement Speed',1),(3,15,'55 Mist Coil Heal/Damage',1),(4,15,'65 Damage',1),(5,20,'-8s Borrowed Time Cooldown',1),(6,20,'100 Aphotic Shield Health/Damage',1),(7,25,'500 AoE Mist Coil',1),(8,25,'-1 Curse of Avernus Attacks Required',1),(9,10,'125 Unstable Concoction Radius',2),(10,10,'15 Attack Speed',2),(11,15,'20 Damage',2),(12,15,'350 Health',2),(13,20,'400 Unstable Concoction Damage',2),(14,20,'25% Cleave',2),(15,25,'50 Chemical Rage Regeneration',2),(16,25,'50 Chemical Rage Movement Speed',2),(17,10,'8% Spell Amplification',3),(18,10,'200 Chilling Touch Attack Range',3),(19,15,'200 Cold Feet Break Distance',3),(20,15,'-2s Ice Vortex Cooldown',3),(21,20,'80 Chilling Touch Damage',3),(22,20,'6% Ice Vortex Slow/Resistance',3),(23,25,'4% Ice Blast Kill Threshold',3),(24,25,'450 AoE Cold Feet',3),(25,10,'-1s Blink Cooldown',4),(26,10,'9 Strength',4),(27,15,'0.7 Mana Void Stun',4),(28,15,'0.6% Max Mana Mana Burn',4),(29,20,'250 Blink Cast Range',4),(30,20,'0.1 Mana Void Damage Multiplier',4),(31,25,'-50s Mana Void Cooldown',4),(32,25,'20% Counterspell Magic Resistance',4),(33,10,'225 Health',5),(34,10,'175 Flux Cast Range',5),(35,15,'40 Magnetic Field Attack Speed',5),(36,15,'8 Armor',5),(37,20,'40 Flux Damage',5),(38,20,'125 Spark Wraith Damage',5),(39,25,'12s Tempest Double Duration',5),(40,25,'35% Lifesteal',5),(41,10,'12 Magic Resistance',6),(42,10,'1.5 Mana Regen',6),(43,15,'30 Counter Helix Damage',6),(44,15,'25 Movement Speed',6),(45,20,'20 Health Regen',6),(46,20,'150 Culling Blade Threshold',6),(47,25,'100 Battle Hunger DPS',6),(48,25,'100 Berserker\'s Call AoE',6),(49,10,'12 Magic Resistance',7),(50,10,'5 Armor',7),(51,15,'5% Fiend\'s Grip Max Mana Drain',7),(52,15,'-3s Brain Sap Cooldown',7),(53,20,'30 Movement Speed',7),(54,20,'-3s Nightmare Cooldown',7),(55,25,'5s Fiend\'s Grip Duration',7),(56,25,'150 Brain Sap Damage/Heal',7),(57,10,'6 Armor',8),(58,10,'5% Spell Amplification',8),(59,15,'250 Health',8),(60,15,'5 Sticky Napalm Damage',8),(61,20,'30 Movement Speed',8),(62,20,'20 Magic Resistance',8),(63,25,'-35s Flaming Lasso Cooldown',8),(64,25,'6.5s Firefly Duration',8),(65,10,'1.75 Mana Regen',9),(66,10,'30 Damage',9),(67,15,'2.5% Wild Axes Damage Amp',9),(68,15,'30 Movement Speed',9),(69,20,'250 Health Beastmaster Controlled',9),(70,20,'35 Boar Damage',9),(71,25,'-30s Primal Road Cooldown',9),(72,25,'30 Inner Beast Attack Speed',9),(73,10,'8% Bloodrage Spell Amplification',10),(74,10,'30 Bloodrage Attack Speed',10),(75,15,'85 Blood Rite Damage',10),(76,15,'10% Rupture Initial Damage',10),(77,20,'400 Health',10),(78,20,'475 Rupture Cast Range',10),(79,25,'14 Max Thirst MS',10),(80,25,'-4s Blood Rite Cooldown',10);
/*!40000 ALTER TABLE `talent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-12-06 21:43:34
